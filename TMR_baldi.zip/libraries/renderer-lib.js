/* TMR renderer (2D): камера, сетка, сущности (фигуры/текстуры/спрайт-листы/текст), частицы, HUD, оверлеи, отладка.
   В режиме 3D рисует только HUD поверх сцены renderer3d. */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  const FONT = "system-ui, sans-serif";
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  window.TMRLibs.renderer = {
    particles: [], floats: [],
    init(r) {
      if (r.mode === "3d") return;
      r.on("collect", e => { this.burst(e.x, e.y, e.color || "#fbbf24", 12); this.float(e.x, e.y - 14, "+" + (e.value ?? 1), e.color || "#fbbf24"); });
      r.on("hit", () => { this.burst(r.player.x, r.player.y, "#f87171", 18); r.camera.shake = 0.5; });
      r.on("win", () => this.burst(r.player.x, r.player.y, "#34d399", 40));
      r.on("float", o => this.float(o.x, o.y, o.text, o.color));
      r.on("reset", () => { this.particles.length = 0; this.floats.length = 0; this.snapCamera(r); });
    },
    burst(x, y, color, n) {
      for (let i = 0; i < n && this.particles.length < 400; i++) {
        const a = Math.random() * Math.PI * 2, s = 40 + Math.random() * 160;
        this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.6, max: 0.6, color, size: 2 + Math.random() * 3 });
      }
    },
    float(x, y, text, color) { this.floats.push({ x, y, text, color: color || "#f8fafc", life: 1 }); },
    cameraTarget(r, px, py) {
      const c = r.camera, w = r.world, vw = r.view.width / c.zoom, vh = r.view.height / c.zoom;
      const tx = w.width <= vw ? (w.width - vw) / 2 : clamp(px - vw / 2, 0, w.width - vw);
      const ty = w.height <= vh ? (w.height - vh) / 2 : clamp(py - vh / 2, 0, w.height - vh);
      return { tx, ty };
    },
    snapCamera(r) { const t = this.cameraTarget(r, r.player.x, r.player.y); r.camera.x = t.tx; r.camera.y = t.ty; },

    render(r, alpha) {
      if (r.mode === "3d") { this.drawHUD(r, r.ctx); return; }
      const ctx = r.ctx, cam = r.camera, w = r.world, V = r.view, dt = r.dt, p = r.player;
      const sim = r.state !== "paused";

      // Позиция игрока с интерполяцией между шагами физики
      const a = r.state === "playing" && p.px !== undefined ? alpha : 1;
      const ix = p.px === undefined ? p.x : p.px + (p.x - p.px) * a;
      const iy = p.py === undefined ? p.y : p.py + (p.y - p.py) * a;

      // Камера следует за игроком
      const t = this.cameraTarget(r, ix, iy), k = 1 - Math.pow(0.0005, dt);
      cam.x += (t.tx - cam.x) * k; cam.y += (t.ty - cam.y) * k;
      if (sim) cam.shake = Math.max(0, cam.shake - dt * 1.5);

      // Частицы и всплывающий текст
      if (sim) {
        for (const q of this.particles) { q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.96; q.vy *= 0.96; }
        this.particles = this.particles.filter(q => q.life > 0);
        for (const f of this.floats) { f.life -= dt * 0.9; f.y -= 30 * dt; }
        this.floats = this.floats.filter(f => f.life > 0);
      }

      // Фон
      ctx.save();
      ctx.fillStyle = "#0b1020"; ctx.fillRect(0, 0, V.width, V.height);
      const sh = cam.shake * 8, sx = sim ? (Math.random() - 0.5) * sh : 0, sy = sim ? (Math.random() - 0.5) * sh : 0;
      ctx.scale(cam.zoom, cam.zoom); ctx.translate(-cam.x + sx, -cam.y + sy);
      ctx.fillStyle = w.background || "#172033"; ctx.fillRect(0, 0, w.width, w.height);

      // Сетка (один путь на все линии)
      if (w.grid !== false) {
        const gs = w.gridSize || 40, x0 = Math.max(0, Math.floor(cam.x / gs) * gs), y0 = Math.max(0, Math.floor(cam.y / gs) * gs);
        const x1 = Math.min(w.width, cam.x + V.width / cam.zoom + gs), y1 = Math.min(w.height, cam.y + V.height / cam.zoom + gs);
        ctx.strokeStyle = "rgba(190,205,240,.07)"; ctx.lineWidth = 1; ctx.beginPath();
        for (let x = x0; x <= x1; x += gs) { ctx.moveTo(x, y0); ctx.lineTo(x, y1); }
        for (let y = y0; y <= y1; y += gs) { ctx.moveTo(x0, y); ctx.lineTo(x1, y); }
        ctx.stroke();
      }
      ctx.strokeStyle = "rgba(190,205,240,.25)"; ctx.lineWidth = 2; ctx.strokeRect(0, 0, w.width, w.height);

      // Сущности (по z, если он задан)
      let list = r.entities;
      if (list.some(e => e.z)) list = [...list].sort((m, n) => (m.z || 0) - (n.z || 0));
      const vx0 = cam.x - 60, vy0 = cam.y - 60, vx1 = cam.x + V.width / cam.zoom + 60, vy1 = cam.y + V.height / cam.zoom + 60;
      for (const e of list) {
        if (!e.active) continue;
        const ew = e.width || (e.radius || 12) * 2, eh = e.height || (e.radius || 12) * 2;
        const ex = e.width ? e.x : e.x - ew / 2, ey = e.height ? e.y : e.y - eh / 2;
        if (ex > vx1 || ey > vy1 || ex + ew < vx0 || ey + eh < vy0) continue;
        this.drawEntity(r, ctx, e);
        if (r.debug) { ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = 1; if (e.width) ctx.strokeRect(e.x, e.y, e.width, e.height); else { ctx.beginPath(); ctx.arc(e.x, e.y, e.radius || 12, 0, 7); ctx.stroke(); } }
      }

      // Игрок
      const blink = p.invuln > 0 && Math.floor(r.clock * 10) % 2 === 0;
      if (!blink) {
        const img = r.assets.getImage(p.texture);
        if (img) ctx.drawImage(img, ix - p.radius, iy - p.radius, p.radius * 2, p.radius * 2);
        else {
          ctx.fillStyle = p.color || "#60a5fa"; ctx.beginPath(); ctx.arc(ix, iy, p.radius, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = "#e0f2fe"; ctx.lineWidth = 3; ctx.stroke();
          ctx.fillStyle = "rgba(255,255,255,.35)"; ctx.beginPath(); ctx.arc(ix - p.radius * 0.3, iy - p.radius * 0.35, p.radius * 0.28, 0, 7); ctx.fill();
        }
      }
      if (r.debug) { ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(p.x, p.y, p.radius, 0, 7); ctx.stroke(); }

      for (const q of this.particles) { ctx.globalAlpha = clamp(q.life / q.max, 0, 1); ctx.fillStyle = q.color; ctx.fillRect(q.x - q.size / 2, q.y - q.size / 2, q.size, q.size); }
      ctx.globalAlpha = 1;
      ctx.textAlign = "center"; ctx.font = `bold 16px ${FONT}`;
      for (const f of this.floats) { ctx.globalAlpha = clamp(f.life, 0, 1); ctx.fillStyle = f.color; ctx.fillText(f.text, f.x, f.y); }
      ctx.globalAlpha = 1;
      ctx.restore();

      this.drawHUD(r, ctx);
    },

    drawEntity(r, ctx, e) {
      const img = e.texture && r.assets.getImage(e.texture);
      if (img && e.type !== "text") {
        const w = e.width || (e.radius ? e.radius * 2 : 32), h = e.height || (e.radius ? e.radius * 2 : 32);
        const dx = e.width ? e.x : e.x - w / 2, dy = e.height ? e.y : e.y - h / 2;
        if (e.frames > 1) { // горизонтальный спрайт-лист: frames, fps
          const fw = img.naturalWidth / e.frames, f = Math.floor(r.clock * (e.fps || 8)) % e.frames;
          ctx.drawImage(img, f * fw, 0, fw, img.naturalHeight, dx, dy, w, h);
        } else ctx.drawImage(img, dx, dy, w, h);
        return;
      }
      switch (e.type) {
        case "wall":
          ctx.fillStyle = e.color || "#46536d"; ctx.fillRect(e.x, e.y, e.width, e.height);
          ctx.fillStyle = "rgba(255,255,255,.08)"; ctx.fillRect(e.x, e.y, e.width, Math.min(4, e.height));
          break;
        case "collectible": {
          const rad = e.radius || 12, bob = Math.sin(r.clock * 3 + e.id) * 3;
          ctx.save(); ctx.translate(e.x, e.y + bob);
          ctx.globalAlpha = 0.18; ctx.fillStyle = e.color || "#fbbf24"; ctx.beginPath(); ctx.arc(0, 0, rad * 1.9, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
          ctx.rotate(r.clock * 1.5); ctx.fillStyle = e.color || "#fbbf24";
          ctx.beginPath(); ctx.moveTo(0, -rad); ctx.lineTo(rad * 0.7, 0); ctx.lineTo(0, rad); ctx.lineTo(-rad * 0.7, 0); ctx.closePath(); ctx.fill();
          ctx.restore(); break;
        }
        case "hazard": {
          const pulse = 0.5 + 0.5 * Math.sin(r.clock * 6);
          ctx.fillStyle = e.color || "#ef4444";
          if (e.width && e.height) ctx.fillRect(e.x, e.y, e.width, e.height);
          else {
            const rad = e.radius || 12;
            ctx.beginPath(); ctx.arc(e.x, e.y, rad, 0, 7); ctx.fill();
            ctx.strokeStyle = `rgba(254,202,202,${0.4 + pulse * 0.5})`; ctx.lineWidth = 3; ctx.stroke();
            ctx.fillStyle = "#7f1d1d"; ctx.beginPath(); ctx.arc(e.x, e.y, rad * 0.4, 0, 7); ctx.fill();
          }
          break;
        }
        case "goal": {
          const locked = e.requires && r.count("collectible") > 0;
          ctx.strokeStyle = locked ? "#64748b" : "#34d399"; ctx.lineWidth = 3;
          if (e.width && e.height) ctx.strokeRect(e.x, e.y, e.width, e.height);
          else { ctx.beginPath(); ctx.arc(e.x, e.y, (e.radius || 20) + Math.sin(r.clock * 4) * 2, 0, 7); ctx.stroke(); }
          break;
        }
        case "text":
          ctx.fillStyle = e.color || "#cbd5e1"; ctx.font = `${e.size || 16}px ${FONT}`; ctx.textAlign = e.align || "left";
          ctx.fillText(e.text || "", e.x, e.y); break;
      }
    },

    label(ctx, s, x, y, color) { ctx.lineWidth = 3; ctx.strokeStyle = "rgba(8,12,24,.85)"; ctx.strokeText(s, x, y); ctx.fillStyle = color || "#f1f5f9"; ctx.fillText(s, x, y); },

    drawHUD(r, ctx) {
      const V = r.view, total = r.entities.filter(e => e.type === "collectible").length, got = total - r.count("collectible");
      ctx.font = `600 15px ${FONT}`; ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      let y = 24;
      if (total) { this.label(ctx, `Кристаллы ${got}/${total}`, 14, y, "#fbbf24"); y += 22; }
      if (total || r.score) { this.label(ctx, `Очки ${r.score}`, 14, y); y += 22; }
      if (r.entities.some(e => e.type === "hazard")) { this.label(ctx, "♥".repeat(Math.max(0, r.lives)) || "—", 14, y, "#f87171"); y += 22; }
      for (const [k, v] of r.hud) { this.label(ctx, `${k}: ${v}`, 14, y, "#94a3b8"); y += 20; }
      ctx.textAlign = "right";
      const tm = r.elapsed, mm = Math.floor(tm / 60), ss = (tm % 60).toFixed(1).padStart(4, "0");
      this.label(ctx, `${mm}:${ss}`, V.width - 14, 24);
      const au = window.TMRLibs.audio; if (au && au.muted) this.label(ctx, "🔇 M", V.width - 14, 46, "#94a3b8");

      if (r.game.hint && r.elapsed < 8 && r.state === "playing") { ctx.textAlign = "center"; ctx.font = `600 15px ${FONT}`; this.label(ctx, r.game.hint, V.width / 2, V.height - 30, "#e2e8f0"); ctx.textAlign = "right"; }
      if (r.mode === "3d") {
        if (r.camera.mode !== "third") { ctx.strokeStyle = "rgba(255,255,255,.8)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(V.width / 2 - 8, V.height / 2); ctx.lineTo(V.width / 2 + 8, V.height / 2); ctx.moveTo(V.width / 2, V.height / 2 - 8); ctx.lineTo(V.width / 2, V.height / 2 + 8); ctx.stroke(); }
        if (r.input && r.input.touch) {
          ctx.lineWidth = 3; ctx.strokeStyle = "rgba(255,255,255,.4)"; ctx.fillStyle = r.input.jump ? "rgba(255,255,255,.35)" : "rgba(255,255,255,.12)";
          ctx.beginPath(); ctx.arc(V.width - 80, V.height - 80, 40, 0, 7); ctx.fill(); ctx.stroke();
          ctx.textAlign = "center"; ctx.font = `600 13px ${FONT}`; ctx.fillStyle = "rgba(255,255,255,.7)"; ctx.fillText("ПРЫЖОК", V.width - 80, V.height - 76); ctx.textAlign = "right";
        }
      }
      const st = r.input && r.input.stick;
      if (st && st.active) {
        ctx.strokeStyle = "rgba(255,255,255,.35)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(st.ox, st.oy, 60, 0, 7); ctx.stroke();
        ctx.fillStyle = "rgba(255,255,255,.3)"; ctx.beginPath(); ctx.arc(st.ox + st.x * 60, st.oy + st.y * 60, 22, 0, 7); ctx.fill();
      }

      if (r.debug) {
        ctx.textAlign = "left"; ctx.font = `12px ui-monospace, monospace`;
        const lines = [`TMR ${r.version}  ${r.fps.toFixed(0)} fps  state=${r.state}`, `mode ${r.mode}  entities ${r.entities.length}`,
          r.mode === "3d" ? `player ${r.player.x.toFixed(1)}, ${r.player.y.toFixed(1)}, ${r.player.z.toFixed(1)}  yaw ${r.player.yaw.toFixed(2)}  cam ${r.camera.mode}` : `player ${r.player.x.toFixed(0)},${r.player.y.toFixed(0)}  cam ${r.camera.x.toFixed(0)},${r.camera.y.toFixed(0)}`, `libs ${r.libList.map(l => l.name).join(", ")}`];
        lines.forEach((s, i) => this.label(ctx, s, 14, V.height - 14 - (lines.length - 1 - i) * 16, "#22d3ee"));
      }

      if (r.state === "paused" || r.state === "won" || r.state === "lost") {
        ctx.fillStyle = "rgba(8,15,30,.76)"; ctx.fillRect(0, 0, V.width, V.height);
        ctx.textAlign = "center"; ctx.fillStyle = "#f8fafc"; ctx.font = `bold 46px ${FONT}`;
        const m = r.game.messages || {};
        const title = r.state === "paused" ? (m.pause || "ПАУЗА") : r.state === "won" ? (m.win || "ПОБЕДА!") : (m.lose || "ИГРА ОКОНЧЕНА");
        ctx.fillText(title, V.width / 2, V.height / 2);
        ctx.font = `20px ${FONT}`; ctx.fillStyle = "#fbbf24";
        const sub = r.state === "paused" ? "P или клик — продолжить"
          : r.state === "won" ? (m.winSub || `Время ${r.elapsed.toFixed(1)} с · очки ${r.score}`) : (m.loseSub || "Кристаллы остались без тебя");
        ctx.fillText(sub, V.width / 2, V.height / 2 + 42);
        if (r.state !== "paused") { ctx.font = `16px ${FONT}`; ctx.fillStyle = "#94a3b8"; ctx.fillText("Enter / клик — заново", V.width / 2, V.height / 2 + 74); }
      }

      r.setStatus(r.state === "won" ? "Победа!" : r.state === "lost" ? "Поражение" : r.state === "paused" ? "Пауза" : total ? `Кристаллы: ${got}/${total}` : "Играем");
    }
  };
})();

/* Игра Baldi's Basics для движка TMR 0.3: 3D-лабиринт (raycasting), персонажи, инвентарь, бег, викторина, концовки.
   Подключается из games/baldi.json. Рисует сама (renderer и physics для 2D отключаются в init). */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  const W = 320, H = 180, MW = 51, MH = 57, PAD = 4, S = v => Math.round(v / 12);
  const R = (a, b) => a + Math.random() * (b - a) | 0;
  const TX = 'textures/', IMG = { carpet: 'png', brick: 'png', ceil: 'png', door: 'png', wood: 'png', baldi: 'png', book: 'png', lk1: 'png', lk2: 'png', m1: 'png', m2: 'png', m3: 'png', cart: 'png', broom: 'png', nokia: 'png', dab: 'png', good: 'png', rare: 'png', title: 'jpg', slots: 'png' };
  const RM = [['g',80,48,176,112],['g',192,48,272,160],['r',368,48,448,144],['r',96,128,176,240],['g',192,160,288,240],['r',288,128,352,240],['g',368,208,448,320],['r',0,240,64,320],['g',96,256,160,368],['y',160,256,224,368],['r',240,256,336,368],['r',400,336,496,416],['r',112,384,176,496],['g',176,384,272,496],['g',288,384,352,480],['r',368,416,432,496],['r',432,416,496,496],['r',336,512,416,592]];
  const ITEMS = { nokia: { icon: '📱', name: 'Nokia 3310', effect: 'place' }, bar: { icon: '🍫', name: 'Батончик', effect: 'stamina', value: 100 } };
  const ITEMS_DEF = JSON.stringify(ITEMS), ICON = new Proxy({}, { get: (t, k) => ITEMS[k] && ITEMS[k].icon });
  const CFG0 = { walkSpeed: 3.2, runSpeed: 5.8, staminaDrain: 22, staminaRegen: 14, baldiCalm: .9, baldiBase: 1.5, baldiPer: .3, baldiSize: 1, detention: 15, nokiaStun: 10, principalSpeed: 1.6, broomSpeed: 2.8, cartSpeed: 1.2, doorReach: 1.7, startItems: ['nokia'], extraItems: {} };
  let CFG = JSON.parse(JSON.stringify(CFG0));
  const hooks = { start: [], update: [], use: [], collect: [] }, modInfo = { names: [], errors: [], pendingHandle: null }, IMG0 = {};
  let sel = 0, boost = 0;
  const MEMES = [['m1','ААААА!'],['m2','Балди нарисованный'],['m3','Внимание! Это ПОДСКАЗКА 👆'],['cart','Тележка с сердцем'],['broom','Gotta Sweep!']];

  const oc = document.createElement('canvas'); oc.width = W; oc.height = H;
  const ctx = oc.getContext('2d'), id = ctx.createImageData(W, H), buf = new Uint32Array(id.data.buffer);
  const img = {}, px = {}, zb = new Float32Array(W);
  let r, map, rid, rs, tables = [], cells = [], nb = [], items = [], placed = [], lockers = [], npcs = [], ex = { x: 0, y: 0 }, tb = {}, doorsAll = [];
  let px_ = 0, py = 0, ang = 0, bx = 0, by = 0, got = 0, anger = 0, stun = 0, angry = false, wt = null, path = [], pt = 0;
  let inv = [], stam = 100, tired = false, autoRun = false, det = 0, dTot = 0, dRun = 0, tRun = 0;
  let menu = true, quizOn = false, qn = 0, inf = 0, ie = '', qOpts = [], qMeme = null, qCap = '', qText = '', qSub = '';
  let endKind = '', endImg = 'dab', msg = { t: '', u: 0 }, uiHit = false, cur = null, firstReset = true;
  const music = {};

  const say = (t, ms) => { msg.t = t; msg.u = performance.now() + ms; };
  const play = k => { const a = window.TMRLibs.audio; if (a && k === 'door') a.sfx('door'); };
  const muted = () => !!(window.TMRLibs.audio && window.TMRLibs.audio.muted);
  function beep(f, d) { try { const a = beep.a || (beep.a = new (window.AudioContext || window.webkitAudioContext)()), o = a.createOscillator(), g = a.createGain(); if (muted()) return; o.frequency.value = f; g.gain.value = .1; o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + d); } catch (e) {} }
  function track(n) { cur = n; for (const k in music) music[k].pause(); if (n && music[n]) { const m = music[n]; m.currentTime = 0; m.loop = true; m.volume = .5; m.muted = muted(); m.play().catch(() => {}); } }
  function pix(i) { const c = document.createElement('canvas'); c.width = i.width; c.height = i.height; const x = c.getContext('2d'); x.drawImage(i, 0, 0); return new Uint32Array(x.getImageData(0, 0, i.width, i.height).data.buffer); }

function gen(){rs=RM.map(([t,a,b,c,d])=>({t,x0:S(a)+PAD,y0:S(b)+PAD,x1:S(c)+PAD,y1:S(d)+PAD,doors:[]}));
for(let d=3;d<8;d++){map=[];rid=[];for(let y=0;y<MH;y++){map.push(Array(MW).fill(1));rid.push(Array(MW).fill(-1))}
rs.forEach(r=>{for(let y=Math.max(1,r.y0-d);y<Math.min(MH-1,r.y1+d);y++)for(let x=Math.max(1,r.x0-d);x<Math.min(MW-1,r.x1+d);x++)map[y][x]=0});
rs.forEach((r,i)=>{for(let y=r.y0;y<r.y1;y++)for(let x=r.x0;x<r.x1;x++){const e=x==r.x0||x==r.x1-1||y==r.y0||y==r.y1-1;map[y][x]=e?1:0;rid[y][x]=e?-2:i}});
rs.forEach((r,i)=>{const c=[];for(let y=r.y0;y<r.y1;y++)for(let x=r.x0;x<r.x1;x++){if(rid[y][x]!=-2)continue;const cx=x>r.x0&&x<r.x1-1,cy=y>r.y0&&y<r.y1-1;if(cx==cy)continue;const ox=cx?0:(x==r.x0?-1:1),oy=cx?(y==r.y0?-1:1):0;if(map[y+oy]?.[x+ox]===0&&rid[y+oy][x+ox]==-1)c.push([x,y])}
r.doors=[];for(let k=0;k<(i==10?2:1)&&c.length;k++){const[x,y]=c.splice(R(0,c.length),1)[0];map[y][x]=2;r.doors.push([x,y])}});
const sx=(rs[9].x0+rs[9].x1)>>1,sy=(rs[9].y0+rs[9].y1)>>1,seen=new Set([sx+','+sy]),q=[[sx,sy]];while(q.length){const[x,y]=q.pop();for(const[a,b]of[[1,0],[-1,0],[0,1],[0,-1]]){const k=(x+a)+','+(y+b);if(map[y+b]?.[x+a]!==undefined&&map[y+b][x+a]!==1&&!seen.has(k)){seen.add(k);q.push([x+a,y+b])}}}
let tot=0;map.forEach(r=>r.forEach(v=>{if(v!==1)tot++}));if(seen.size==tot||d==7)break}
tables=[];tb={};const cf=rs[10];
for(let y=cf.y0+2;y<cf.y1-1;y+=2)for(let x=cf.x0+2;x<cf.x1-1;x+=3){if(cf.doors.some(([dx,dy])=>Math.abs(dx-x)<3&&Math.abs(dy-y)<3))continue;tables.push({x:x+.5,y:y+.5});tb[x+','+y]=1}
doorsAll=[];rs.forEach(r=>r.doors.forEach(d=>doorsAll.push(d)));const nearD=(x,y,k)=>doorsAll.some(([a,b])=>Math.abs(a-x)<k&&Math.abs(b-y)<k);
const addP=(x,y,k,h,r)=>{if(tb[x+','+y]||nearD(x,y,3))return;tb[x+','+y]=1;tables.push({x:x+.5,y:y+.5,k,h,r})};
rs.forEach((r,i)=>{if(r.t=='g'){for(let n=0;n<4;n++)addP(R(r.x0+1,r.x1-1),R(r.y0+1,r.y1-1),'desk',.45,.5);addP(r.x0+1,r.y0+1,'plant',.55,.4)}
if(r.t=='y'){addP(r.x0+2,r.y0+2,'desk',.5,.5);addP(r.x1-2,r.y0+1,'plant',.55,.4)}
if(r.t=='r'&&i!=10)for(let n=0;n<2;n++)addP(R(r.x0+1,r.x1-1),R(r.y0+1,r.y1-1),n?'plant':'bin',.45,.4)});
for(let y=1;y<MH-1;y++)for(let x=1;x<MW-1;x++)if(map[y][x]===0&&rid[y][x]==-1&&Math.random()<.025&&[[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>map[y+b][x+a]===1))addP(x,y,['bin','plant','bench'][R(0,3)],.4,.5);
cells=[];const cor=[];for(let y=1;y<MH-1;y++)for(let x=1;x<MW-1;x++)if(map[y][x]===0&&!tb[x+','+y]){cells.push([x,y]);if(rid[y][x]==-1)cor.push([x,y])}
nb=[];rs.forEach(r=>{if(r.t=='g'){let x,y;do{x=R(r.x0+1,r.x1-1);y=R(r.y0+1,r.y1-1)}while(tb[x+','+y]);nb.push({x:x+.5,y:y+.5})}});
items=[];['nokia','bar','bar'].forEach(k=>{const[x,y]=cor[R(0,cor.length)];items.push({x:x+.5,y:y+.5,k})});placed=[];
const lc=[];for(let y=1;y<MH-1;y++)for(let x=1;x<MW-1;x++)if(map[y][x]===1)for(const[a,b]of[[1,0],[-1,0],[0,1],[0,-1]])if(map[y+b]?.[x+a]===0&&rid[y+b][x+a]==-1)lc.push({x:x+.5+a*.62,y:y+.5+b*.62});
lc.sort(()=>Math.random()-.5);lockers=lc.slice(0,90).map((l,i)=>({x:l.x,y:l.y,k:i%2?'lk1':'lk2'}));
const e=rs[17];ex={x:(e.x0+e.x1)/2,y:(e.y0+e.y1)/2}}
function wall(x,y){return map[y|0]?.[x|0]!==0}
function ok(x,y){const r=.2;return!wall(x+r,y+r)&&!wall(x-r,y+r)&&!wall(x+r,y-r)&&!wall(x-r,y-r)&&!tables.some(t=>Math.hypot(t.x-x,t.y-y)<(t.r||.6)+.1)}
function move(dx,dy){if(ok(px_+dx,py))px_+=dx;if(ok(px_,py+dy))py+=dy}
function openDoors(x,y,r,snd){for(let j=Math.floor(y-r);j<=y+r;j++)for(let i=Math.floor(x-r);i<=x+r;i++)if(map[j]?.[i]===2&&Math.hypot(i+.5-x,j+.5-y)<r){map[j][i]=0;if(snd)play('door')}}
function bfsE(e,gx,gy){const st=[e.x|0,e.y|0],g=[gx|0,gy|0],q=[st],pr={[st]:null};while(q.length){const c=q.shift();if(c[0]==g[0]&&c[1]==g[1])break;for(const[a,b]of[[1,0],[-1,0],[0,1],[0,-1]]){const n=[c[0]+a,c[1]+b];if(map[n[1]]?.[n[0]]===undefined||map[n[1]][n[0]]===1||tb[n]||n in pr)continue;pr[n]=c;q.push(n)}}
let c=g;if(!(c in pr))return[];const p=[];while(c){p.unshift(c);c=pr[c]}return p}
function spot(i){const r=rs[i],cx=(r.x0+r.x1)/2,cy=(r.y0+r.y1)/2;let best=null,bd=1e9;for(let y=r.y0+1;y<r.y1-1;y++)for(let x=r.x0+1;x<r.x1-1;x++){if(tb[x+','+y])continue;const d=Math.hypot(x+.5-cx,y+.5-cy);if(d<bd){bd=d;best=[x+.5,y+.5]}}return best}
function sees(e){const n=Math.ceil(Math.hypot(e.x-px_,e.y-py)/.3);for(let i=1;i<n;i++){const t=i/n;if(map[(e.y+(py-e.y)*t)|0]?.[(e.x+(px_-e.x)*t)|0]!==0)return false}return true}
function tele(a,b){const c=cells.filter(([x,y])=>{const d=Math.hypot(x+.5-px_,y+.5-py);return d>a&&d<b});if(!c.length)return;const[x,y]=c[R(0,c.length)];bx=x+.5;by=y+.5;path=[];pt=0;say('Балди телепортировался!',2500);beep(150,.3)}
function drawS(im,cx,w,h,d,y){const x0=cx-w/2;for(let x=Math.max(0,x0|0);x<Math.min(W,x0+w);x++){if(zb[x]<d)continue;ctx.drawImage(im,(x-x0)/w*im.width|0,0,1,im.height,x,y,1,h)}}
function dim(c,f){const r=(c&255)*f,g=(c>>8&255)*f,b=(c>>16&255)*f;return 0xff000000|(b<<16)|(g<<8)|r}
function render(){const dx=Math.cos(ang),dy=Math.sin(ang),pxn=-dy*.66,pyn=dx*.66;
for(let y=H/2|0;y<H;y++){const rd=.5*H/(y-H/2+.01);let x0=px_+rd*(dx-pxn),y0=py+rd*(dy-pyn);const sx=2*rd*pxn/W,sy=2*rd*pyn/W,f=Math.max(.35,1-rd/9);
for(let x=0;x<W;x++){const cx=Math.floor(x0),cy=Math.floor(y0),u=((x0-cx)*128)&127,v=((y0-cy)*128)&127,w=px.carpet;
buf[y*W+x]=dim(w[v*128+u],f);buf[(H-1-y)*W+x]=dim(px.ceil[v*128+u],f);x0+=sx;y0+=sy}}
for(let x=0;x<W;x++){const cam=2*x/W-1,rx=dx+pxn*cam,ry=dy+pyn*cam;let mx=px_|0,my=py|0;const ddx=Math.abs(1/rx),ddy=Math.abs(1/ry);let sx=rx<0?-1:1,sy=ry<0?-1:1,sdx=(rx<0?px_-mx:mx+1-px_)*ddx,sdy=(ry<0?py-my:my+1-py)*ddy,side=0;
for(let i=0;i<60;i++){if(sdx<sdy){sdx+=ddx;mx+=sx;side=0}else{sdy+=ddy;my+=sy;side=1}if(map[my]?.[mx]!==0)break}
const pd=side?sdy-ddy:sdx-ddx;zb[x]=pd;const lh=H/pd|0,ds=Math.max(0,H/2-lh/2|0),de=Math.min(H-1,H/2+lh/2|0);let wx=side?px_+pd*rx:py+pd*ry;wx-=Math.floor(wx);const tx=wx*128|0,T=map[my]?.[mx]===2?px.door:px.brick;
const sh=Math.max(.3,1-pd/9)*(side?.8:1);for(let y=ds;y<=de;y++){const v=((y-(H/2-lh/2))/lh*128)|0;buf[y*W+x]=dim(T[(v&127)*128+tx],sh)}}
ctx.putImageData(id,0,0);
const sp=[];nb.forEach(n=>sp.push({x:n.x,y:n.y,k:'book',h:.3,l:.25}));items.forEach(n=>sp.push({x:n.x,y:n.y,k:n.k,h:.3,l:.2}));placed.forEach(n=>sp.push({x:n.x,y:n.y,k:'nokia',h:.3,l:.2}));lockers.forEach(n=>{if(Math.abs(n.x-px_)<14&&Math.abs(n.y-py)<14)sp.push({x:n.x,y:n.y,k:n.k,h:.85,l:0})});tables.forEach(n=>{if(Math.abs(n.x-px_)<14&&Math.abs(n.y-py)<14)sp.push({x:n.x,y:n.y,k:n.k||'table',h:n.h||.5,l:0})});npcs.forEach(e=>sp.push({x:e.x,y:e.y,k:e.k,h:e.h,l:0}));sp.push({x:bx,y:by,k:'baldi',h:Math.min(1.25,.75+.07*got)*CFG.baldiSize,l:0});if(got==7)sp.push({x:ex.x,y:ex.y,k:0,h:.9,l:0});
sp.sort((a,b)=>Math.hypot(b.x-px_,b.y-py)-Math.hypot(a.x-px_,a.y-py));
for(const s of sp){const rx=s.x-px_,ry=s.y-py,inv=1/(pxn*dy-dx*pyn),tx=inv*(dy*rx-dx*ry),ty=inv*(-pyn*rx+pxn*ry);if(ty<.15)continue;
const scx=W/2*(1+tx/ty),sz=Math.abs(H/ty),h=sz*s.h,bot=H/2+sz/2-sz*s.l,y=bot-h;
if(s.k){const im=img[s.k]||itemSprite(s.k),w=h*im.width/im.height;drawS(im,scx,w,h,ty,y)}else{ctx.fillStyle='#ffd400';const x0=scx-sz*.4;for(let x=Math.max(0,x0|0);x<Math.min(W,x0+sz*.8);x++)if(zb[x]>=ty)ctx.fillRect(x,y,1,h)}}
}

function walk(dt,sp){if(path.length>1){const[tx,ty]=path[1],dx=tx+.5-bx,dy=ty+.5-by,d=Math.hypot(dx,dy);if(d<.08)path.shift();else{bx+=dx/d*sp*dt;by+=dy/d*sp*dt}}else{const dx=px_-bx,dy=py-by,d=Math.hypot(dx,dy)||1;if(angry){bx+=dx/d*sp*dt;by+=dy/d*sp*dt}}}

  function newGame() {
    gen(); [px_, py] = spot(7); ang = 0; [bx, by] = spot(2);
    got = 0; anger = 0; stun = 0; angry = false; wt = null; path = []; pt = 0; placed = [];
    inv = [0, 1, 2].map(i => CFG.startItems[i] || null); sel = 0; stam = 100; tired = false; autoRun = false; det = 0; dTot = dRun = tRun = 0; quizOn = false; boost = 0;
    const cc = cells.filter(([x, y]) => rid[y][x] == -1);
    npcs = [['m3', CFG.principalSpeed, 1.0], ['broom', CFG.broomSpeed, .9], ['cart', CFG.cartSpeed, .6]].map(([k, sp, h]) => { const c = cc[R(0, cc.length)]; return { k, sp, h, x: c[0] + .5, y: c[1] + .5, path: [], wt: null, cd: 0 }; });
    say('Найди 7 тетрадей в зелёных классах! Балди пока добрый', 3500);
    const cor = cells.filter(([x, y]) => rid[y][x] == -1);
    for (const k in CFG.extraItems) for (let n = 0; n < CFG.extraItems[k]; n++) { const c = cor[R(0, cor.length)]; items.push({ x: c[0] + .5, y: c[1] + .5, k }); }
    runHooks('start');
    if (!menu) track('music');
  }
  function runHooks(ev, a) { for (const f of hooks[ev]) { try { f(a); } catch (e) { console.error('[baldi mod]', e); } } }
  function nearestDoor() { let best = null, bd = CFG.doorReach; for (let j = Math.floor(py - 2); j <= py + 2; j++) for (let i = Math.floor(px_ - 2); i <= px_ + 2; i++) if (map[j] && map[j][i] === 2) { const d = Math.hypot(i + .5 - px_, j + .5 - py); if (d < bd) { bd = d; best = [i, j]; } } return best; }
  const doorNear = () => !!nearestDoor();
  function openDoor() { if (r.state !== 'playing' || menu || quizOn || det > 0) return; const d = nearestDoor(); if (!d) { say('Рядом нет двери', 900); return; } map[d[1]][d[0]] = 0; play('door'); }
  function use(i) {
    if (i === undefined) i = sel;
    const k = inv[i]; if (!k || r.state !== 'playing' || menu || quizOn) return;
    const d = ITEMS[k] || {};
    if (d.effect == 'place') { placed.push({ x: px_ + Math.cos(ang) * .5, y: py + Math.sin(ang) * .5 }); say(d.name + ' положена', 1200); }
    else if (d.effect == 'stamina') { stam = Math.min(100, stam + (d.value || 100)); tired = false; say('Выносливость восстановлена!', 1500); }
    else if (d.effect == 'stun') { stun = Math.max(stun, d.value || 5); say('Балди замер!', 1500); }
    else if (d.effect == 'teleport') tele(10, 20);
    else if (d.effect == 'speed') { boost = d.value || 5; say('Ускорение!', 1500); }
    runHooks('use', k); beep(660, .1); inv[i] = null;
  }
  function quiz() {
    quizOn = true; track(got % 2 ? 'q1' : 'q2'); qn = 0;
    const mm = MEMES[R(0, MEMES.length)]; qMeme = Math.random() < .7 ? mm[0] : null; qCap = qMeme ? mm[1] : '';
    ask();
  }
  function fin() {
    quizOn = false; track('music');
    if (got == 2 && !angry) { angry = true; tele(5, 8); say('Балди разозлился!', 3000); }
    else if (angry) tele(8, 16); else say(got + '/7 — Балди пока добрый', 2500);
    if (got == 7) say('Все тетради! Беги к выходу — внизу справа!', 4000);
  }
  function ask() {
    if (got == 2 && qn == 2) { inf = 0; ie = '1 + 1'; return askInf(); }
    const a = R(1, 10), b = R(1, 10), plus = Math.random() < .6, ans = plus ? a + b : a - b;
    qText = a + (plus ? ' + ' : ' − ') + b + ' = ?'; qSub = 'Вопрос ' + (qn + 1) + ' из 3';
    const o = new Set([ans]); while (o.size < 3) o.add(ans + R(0, 7) - 3);
    qOpts = [...o].sort(() => Math.random() - .5).map(v => ({ t: '' + v, ok: v == ans }));
  }
  function askInf() {
    qText = ie + ' = ?'; qSub = 'Вопрос 3 из ∞'; qCap = 'Это невозможно решить 😈';
    qOpts = ['∞', '?!?', 'Ω', 'ERR', '0=1', 'x²−∞'].sort(() => Math.random() - .5).slice(0, 3).map(t => ({ t, ok: false, inf: true }));
  }
  function answer(i) {
    const o = qOpts[i]; if (!o) return;
    if (o.inf) { beep(120 + inf * 20, .2); ie += ' + ' + R(1, 9) + ' × ' + R(1, 9); if (++inf >= 6) fin(); else askInf(); return; }
    if (!o.ok) { anger += .2; say('Неправильно!', 1500); }
    if (++qn < 3) ask(); else fin();
  }

  function update(rt, dt) {
    if (menu || quizOn) return;
    runHooks('update', dt); boost = Math.max(0, boost - dt);
    const ax = rt.axis();
    if (det > 0) { det -= dt; stun = Math.max(stun, .1); if (det <= 0) say('Свободен! Больше не бегай', 2500); }
    const fw = det > 0 ? 0 : -ax.y; ang += ax.x * 2.2 * dt;
    const moving = Math.abs(fw) > .1, run = (rt.keys.has('shift') || autoRun) && moving && stam > 0 && !tired;
    if (run) { stam -= CFG.staminaDrain * dt; if (stam <= 0) { stam = 0; tired = true; } } else { stam = Math.min(100, stam + CFG.staminaRegen * dt); if (tired && stam > 25) tired = false; }
    if (moving) { const s = (run ? CFG.runSpeed : CFG.walkSpeed) * (boost > 0 ? 1.5 : 1) * dt * fw, ox = px_, oy = py; move(Math.cos(ang) * s, Math.sin(ang) * s); const d = Math.hypot(px_ - ox, py - oy); dTot += d; if (run) { dRun += d; tRun += dt; } }
    items = items.filter(n => { if (Math.hypot(n.x - px_, n.y - py) < .6) { const i = inv.indexOf(null); if (i < 0) { say('Инвентарь полон', 900); return true; } inv[i] = n.k; beep(520, .2); say(((ITEMS[n.k] || {}).name || 'Предмет') + ' в инвентаре', 1800); return false; } return true; });
    placed = placed.filter(n => { if (Math.hypot(n.x - bx, n.y - by) < .7) { stun = CFG.nokiaStun; say('Балди сломался от Нокии', CFG.nokiaStun * 1000); beep(200, .4); return false; } return true; });
    for (let i = 0; i < nb.length; i++) { const n = nb[i]; if (Math.hypot(n.x - px_, n.y - py) < .6) { nb.splice(i, 1); got++; rt.emit('collect', { x: 0, y: 0 }); runHooks('collect', got); quiz(); return; } }
    if (got == 7 && Math.hypot(ex.x - px_, ex.y - py) < .9) {
      endKind = 'win'; endImg = Math.random() < .7 ? 'good' : 'dab';
      const b = rt.save && rt.save.get('best', null), cur_ = rt.elapsed; if (rt.save && (!b || cur_ < b)) rt.save.set('best', cur_);
      rt.setState('won'); return;
    }
    stun = Math.max(0, stun - dt);
    if (!stun) {
      if (!angry) { if (!wt || Math.hypot(wt[0] + .5 - bx, wt[1] + .5 - by) < .6 || path.length < 2) { wt = cells[R(0, cells.length)]; path = bfsE({ x: bx, y: by }, wt[0], wt[1]); } walk(dt, CFG.baldiCalm); }
      else { pt -= dt; if (pt <= 0) { path = bfsE({ x: bx, y: by }, px_, py); pt = .3; } walk(dt, CFG.baldiBase + CFG.baldiPer * got + anger); }
      openDoors(bx, by, .9, Math.hypot(bx - px_, by - py) < 8);
      if (angry && Math.hypot(bx - px_, by - py) < .55) { endKind = 'lose'; endImg = 'rare'; rt.setState('lost'); return; }
    }
    npcs.forEach(e => {
      if (!e.wt || e.path.length < 2 || Math.hypot(e.wt[0] + .5 - e.x, e.wt[1] + .5 - e.y) < .6) { e.wt = cells[R(0, cells.length)]; e.path = bfsE(e, e.wt[0], e.wt[1]); }
      if (e.path.length > 1) { const [tx, ty] = e.path[1], dx = tx + .5 - e.x, dy = ty + .5 - e.y, d = Math.hypot(dx, dy); if (d < .08) e.path.shift(); else { e.x += dx / d * e.sp * dt; e.y += dy / d * e.sp * dt; } }
      openDoors(e.x, e.y, .9, 0); e.cd = Math.max(0, e.cd - dt); const d = Math.hypot(e.x - px_, e.y - py);
      if (e.k == 'broom' && d < .8 && !e.cd && det <= 0) { const c = cells[R(0, cells.length)]; px_ = c[0] + .5; py = c[1] + .5; e.cd = 5; say('Метла вымела тебя!', 2000); }
      if (e.k == 'cart' && d < .8 && !e.cd) { stam = 0; tired = true; e.cd = 5; say('Тележка сбила тебя с ног!', 2000); }
      if (e.k == 'm3' && run && d < 9 && det <= 0 && sees(e)) { const p = spot(9); px_ = p[0]; py = p[1]; det = CFG.detention; say('Заусенец: Не бегать по коридору!', 3000); }
    });
  }

  // ---------- Интерфейс (рисуется на холсте 960×540) ----------
  const lab = (g, s, x, y, c) => { g.lineWidth = 4; g.strokeStyle = 'rgba(0,0,0,.85)'; g.strokeText(s, x, y); g.fillStyle = c || '#fff'; g.fillText(s, x, y); };
  const rect = (g, x, y, w, h, f, s) => { g.fillStyle = f; g.fillRect(x, y, w, h); if (s) { g.strokeStyle = s; g.lineWidth = 2; g.strokeRect(x, y, w, h); } };
  const FRM = { w: 300, h: 134, x: 12, y: 540 - 72 - 134 }, HOLES = [[46, 13, 94, 66], [124, 21, 170, 67], [197, 21, 246, 67]];
  const slotRect = i => { const k = FRM.w / 256, h = HOLES[i]; return { x: FRM.x + h[0] * k, y: FRM.y + h[1] * k, w: (h[2] - h[0]) * k, h: (h[3] - h[1]) * k }; };
  const BTN = ['run', 'door', 'use'], btnRect = n => ({ x: 960 - 92, y: 540 - 152 - n * 86, w: 76, h: 76 });
  // невидимые хитбоксы поверх надписей START / OPTIONS / EXIT на титульной картинке
  const MENU = { play: { x: 385, y: 262, w: 190, h: 62 }, mods: { x: 360, y: 342, w: 240, h: 58 }, url: { x: 400, y: 422, w: 160, h: 60 } };
  const hit = (p, o) => p.x >= o.x && p.x <= o.x + o.w && p.y >= o.y && p.y <= o.y + o.h;
  function bigImage(g, name, cx, y, maxH) { const i = r.assets.getImage(TX + name + '.' + IMG[name]); if (!i) return 0; const h = Math.min(maxH, i.naturalHeight), w = i.naturalWidth * h / i.naturalHeight; g.drawImage(i, cx - w / 2, y, w, h); return h; }

  function drawUI(g) {
    const V = r.view, now = performance.now();
    g.textBaseline = 'alphabetic'; g.font = '600 18px system-ui, sans-serif'; g.textAlign = 'left';
    lab(g, 'Тетради: ' + got + '/7', 16, 28); lab(g, 'Путь: ' + dTot.toFixed(0) + ' м', 16, 52, '#cbd5e1');
    lab(g, 'Бег: ' + dRun.toFixed(0) + ' м, ' + tRun.toFixed(0) + ' с', 16, 76, '#cbd5e1');
    rect(g, 16, 88, 130, 12, 'rgba(0,0,0,.6)', '#fff'); rect(g, 17, 89, 128 * stam / 100, 10, tired ? '#d33' : '#4c4');
    // миникарта
    const mx = V.width - MW * 2 - 12, my = 12; rect(g, mx - 2, my - 2, MW * 2 + 4, MH * 2 + 4, 'rgba(0,0,0,.55)');
    for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) if (map[y][x]) rect(g, mx + x * 2, my + y * 2, 2, 2, map[y][x] == 2 ? '#38f' : '#bbb');
    rect(g, mx + px_ * 2 - 2, my + py * 2 - 2, 5, 5, '#0f0'); rect(g, mx + bx * 2 - 2, my + by * 2 - 2, 5, 5, '#f00');
    npcs.forEach(e => rect(g, mx + e.x * 2 - 2, my + e.y * 2 - 2, 5, 5, e.k == 'm3' ? '#4af' : '#fa0'));
    // инвентарь в левом нижнем углу
    if (img.slots) g.drawImage(img.slots, FRM.x, FRM.y, FRM.w, FRM.h);
    for (let i = 0; i < 3; i++) { const s = slotRect(i); rect(g, s.x, s.y, s.w, s.h, 'rgba(20,20,30,.82)'); if (i == sel) { g.strokeStyle = '#ffd400'; g.lineWidth = 4; g.strokeRect(s.x, s.y, s.w, s.h); } g.textAlign = 'center'; g.font = '34px system-ui'; g.fillStyle = '#fff'; g.fillText(ICON[inv[i]] || '', s.x + s.w / 2, s.y + s.h / 2 + 12); g.font = '12px system-ui'; g.fillStyle = '#aaa'; g.fillText(i + 1, s.x + 8, s.y + 14); }
    const near = doorNear();
    BTN.forEach((n, i) => { const b = btnRect(i), on = n == 'run' ? autoRun : n == 'door' ? near : !!inv[sel]; rect(g, b.x, b.y, b.w, b.h, on ? 'rgba(60,200,60,.75)' : 'rgba(40,40,50,.7)', '#fff'); g.textAlign = 'center'; g.font = '38px system-ui'; g.fillStyle = '#fff'; g.fillText(n == 'run' ? '🏃' : n == 'door' ? '🚪' : '⚡', b.x + b.w / 2, b.y + 48); g.font = '11px system-ui'; g.fillStyle = '#cfd'; g.fillText(n == 'run' ? 'бег' : n == 'door' ? 'дверь' : 'исп.', b.x + b.w / 2, b.y + 69); });
    // сообщения
    g.font = 'bold 26px monospace'; g.textAlign = 'center';
    if (det > 0) lab(g, 'Кабинет директора Заусенца: сиди ещё ' + Math.ceil(det) + ' с', V.width / 2, 190, '#fc4');
    else if (now < msg.u) lab(g, msg.t, V.width / 2, 190);
  }
  function drawQuiz(g) {
    const V = r.view; rect(g, 0, 0, V.width, V.height, 'rgba(0,0,0,.82)'); g.textAlign = 'center';
    let y = 20; if (qMeme) { y += bigImage(g, qMeme, 480, y, 170) + 8; g.font = 'bold 20px system-ui'; lab(g, qCap, 480, y + 14, '#fc4'); y += 30; } else if (qCap) { g.font = 'bold 20px system-ui'; lab(g, qCap, 480, y + 14, '#fc4'); y += 30; }
    g.font = 'bold 52px "Comic Sans MS", cursive, sans-serif'; lab(g, qText.length > 40 ? qText.slice(-40) : qText, 480, y + 70);
    g.font = '18px system-ui'; lab(g, qSub, 480, y + 100, '#aaa');
    qOpts.forEach((o, i) => { const b = o.box = { x: 480 - 255 + i * 175, y: y + 125, w: 160, h: 80 }; rect(g, b.x, b.y, b.w, b.h, '#3b9b3b', '#fff'); g.font = 'bold 34px system-ui'; g.fillStyle = '#fff'; g.fillText(o.t, b.x + 80, b.y + 53); g.font = '13px system-ui'; g.fillStyle = '#d8f5d8'; g.fillText('' + (i + 1), b.x + 12, b.y + 18); });
  }
  function drawEnd(g) {
    const V = r.view, win = r.state == 'won'; rect(g, 0, 0, V.width, V.height, 'rgba(0,0,0,.8)'); g.textAlign = 'center';
    const h = bigImage(g, endImg, 480, 30, 220);
    g.font = 'bold 44px system-ui'; lab(g, win ? 'Ты победил! 🥒' : 'Балди поймал тебя!', 480, 40 + h + 44, win ? '#6f6' : '#f66');
    g.font = '26px system-ui'; lab(g, win ? 'Хорошая концовка' : 'Концовка для смерти', 480, 40 + h + 82, '#fc4');
    const b = r.save && r.save.get('best', null);
    g.font = '18px system-ui'; lab(g, 'Пройдено ' + dTot.toFixed(0) + ' м · бегом ' + dRun.toFixed(0) + ' м · ' + tRun.toFixed(0) + ' с бега' + (win && b ? ' · рекорд ' + b.toFixed(0) + ' с' : ''), 480, 40 + h + 116, '#ccc');
    g.font = '16px system-ui'; lab(g, 'Enter / клик — ещё раз', 480, 40 + h + 146, '#999');
  }

  function itemSprite(k) { const c = document.createElement('canvas'); c.width = c.height = 48; const x = c.getContext('2d'); x.font = '40px system-ui'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText((ITEMS[k] && ITEMS[k].icon) || '❓', 24, 26); return (img[k] = c); }
  function makeSprites() {
      const mk = (w, h, f) => { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d')); return c; };
      img.table = mk(96, 56, x => { x.fillStyle = '#3a2a1a'; [6, 22, 69, 84].forEach(l => x.fillRect(l, 18, 6, 38)); x.drawImage(img.wood, 0, 0, img.wood.width, img.wood.height, 0, 4, 96, 18); x.fillStyle = 'rgba(0,0,0,.4)'; x.fillRect(0, 19, 96, 3); });
      img.bar = mk(40, 22, x => { x.fillStyle = '#c9742b'; x.fillRect(0, 0, 40, 22); x.fillStyle = '#ffd54a'; x.fillRect(3, 8, 34, 6); x.fillStyle = '#fff'; x.fillRect(0, 0, 40, 3); });
      img.desk = mk(60, 44, x => { x.fillStyle = '#5a3a1a'; x.fillRect(4, 14, 5, 30); x.fillRect(51, 14, 5, 30); x.fillStyle = '#8a5a2b'; x.fillRect(0, 0, 60, 16); x.fillStyle = '#c98a4a'; x.fillRect(0, 0, 60, 4); });
      img.plant = mk(32, 52, x => { x.fillStyle = '#b5651d'; x.fillRect(8, 32, 16, 20); x.fillStyle = '#2f9e44'; x.beginPath(); x.arc(16, 16, 15, 0, 7); x.fill(); x.fillStyle = '#46c25f'; x.beginPath(); x.arc(12, 12, 7, 0, 7); x.fill(); });
      img.bin = mk(28, 44, x => { x.fillStyle = '#667'; x.fillRect(3, 6, 22, 38); x.fillStyle = '#99a'; x.fillRect(0, 0, 28, 8); x.fillStyle = '#556'; x.fillRect(8, 14, 3, 26); x.fillRect(17, 14, 3, 26); });
      img.bench = mk(80, 40, x => { x.fillStyle = '#223'; x.fillRect(4, 16, 6, 24); x.fillRect(70, 16, 6, 24); x.fillStyle = '#2b5fd9'; x.fillRect(0, 0, 80, 10); x.fillStyle = '#3d78ff'; x.fillRect(0, 10, 80, 8); });
    for (const k in ITEMS) if (!img[k]) { const c = document.createElement('canvas'); c.width = c.height = 48; const x = c.getContext('2d'); x.font = '40px system-ui'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(ITEMS[k].icon, 24, 26); img[k] = c; }
  }

  // ---------- Моды: mods/mods.json (запрос), выбранная папка/файлы, ссылка ----------
  const IDB = () => new Promise((res, rej) => { const q = indexedDB.open('tmr-baldi', 1); q.onupgradeneeded = () => q.result.createObjectStore('kv'); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
  const idbGet = async k => { const db = await IDB(); return new Promise((res, rej) => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); };
  const idbSet = async (k, v) => { const db = await IDB(); return new Promise((res, rej) => { const t = db.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); t.oncomplete = () => res(); t.onerror = () => rej(t.error); }); };
  const loadImg = url => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('не загрузилась картинка ' + String(url).slice(0, 50))); i.src = url; });
  const num = (v, d) => (typeof v === 'number' && isFinite(v) ? v : d);
  const EFFECTS = ['place', 'stamina', 'stun', 'teleport', 'speed'];
  function defItem(d) {
    if (!d || !/^[a-z0-9_]{1,16}$/.test(d.id || '')) throw new Error('у предмета нужен id (a-z, 0-9, _)');
    const eff = EFFECTS.includes(d.effect) ? d.effect : 'stamina';
    ITEMS[d.id] = { icon: String(d.icon || '❓').slice(0, 4), name: String(d.name || d.id).slice(0, 24), effect: eff, value: num(d.value, 5) };
    delete img[d.id];
    if (d.spawn > 0) CFG.extraItems[d.id] = Math.min(10, d.spawn | 0);
  }
  function setSound(k, url) {
    if (music[k]) { music[k].src = url; return; }
    const a = window.TMRLibs.audio; if (!a || !['door', 'win', 'lose'].includes(k)) return;
    a.cfg.sfx = a.cfg.sfx || {}; a.cfg.sfx[k] = url; const au = new Audio(); au.preload = 'auto'; au.src = url; a.files[k] = { a: au, ok: true };
  }
  async function applyMod(j, texQ) {
    if (j.js) {
      if (j.picked && !confirm('Мод «' + j.name + '» содержит код. Запускать? Подключайте только доверенные моды.')) throw new Error('отменён');
      const api = { settings: CFG, items: ITEMS, defItem, say, on: (ev, f) => { if (hooks[ev]) hooks[ev].push(f); },
        state: () => ({ got, angry, x: px_, y: py, baldi: { x: bx, y: by }, stamina: stam }), giveItem: k => { const i = inv.indexOf(null); if (i >= 0 && ITEMS[k]) inv[i] = k; } };
      new Function('api', j.text)(api); modInfo.names.push(j.name.replace(/\.js$/i, '')); return;
    }
    const m = JSON.parse(j.text);
    for (const k in m.settings || {}) {
      if (!(k in CFG0)) continue; const d = CFG0[k], v = m.settings[k];
      if (typeof d === 'number') CFG[k] = num(v, d);
      else if (Array.isArray(d) && Array.isArray(v)) CFG[k] = v.filter(x => typeof x === 'string').slice(0, 3);
      else if (k === 'extraItems' && v && typeof v === 'object') CFG[k] = { ...CFG[k], ...v };
    }
    for (const d of m.items || []) defItem(d);
    for (const k in m.textures || {}) if (k in IMG) texQ.push([k, await loadImg(j.res(m.textures[k]))]);
    for (const k in m.sounds || {}) setSound(k, j.res(m.sounds[k]));
    modInfo.names.push(m.name || j.name.replace(/\.json$/i, ''));
  }
  async function readHandle(h) {
    try { h = await h.getDirectoryHandle('mods'); } catch (e) { /* файлы лежат прямо в выбранной папке */ }
    const files = []; for await (const [name, fh] of h.entries()) if (fh.kind === 'file') files.push({ name, blob: await fh.getFile() }); return files;
  }
  async function loadMods() {
    CFG = JSON.parse(JSON.stringify(CFG0)); for (const k of Object.keys(ITEMS)) delete ITEMS[k]; Object.assign(ITEMS, JSON.parse(ITEMS_DEF));
    for (const k in hooks) hooks[k].length = 0; modInfo.names = []; modInfo.errors = []; Object.assign(img, IMG0);
    const jobs = [], texQ = [];
    try { const m = await (await fetch('mods/mods.json', { cache: 'no-cache' })).json(); for (const n of m.mods || []) { try { const t = await (await fetch('mods/' + n, { cache: 'no-cache' })).text(); jobs.push({ name: n, text: t, js: /\.js$/i.test(n), res: p => 'mods/' + p }); } catch (e) { modInfo.errors.push(n + ': ' + e.message); } } } catch (e) { /* mods.json необязателен */ }
    let saved = null; try { saved = await idbGet('mods'); } catch (e) { /* IndexedDB недоступна */ }
    let files = null;
    if (saved && saved.kind === 'handle') { try { if ((await saved.handle.queryPermission({ mode: 'read' })) === 'granted') files = await readHandle(saved.handle); else modInfo.pendingHandle = saved.handle; } catch (e) { modInfo.errors.push('папка модов: ' + e.message); } }
    else if (saved && saved.kind === 'files') files = saved.files;
    if (files) { const urls = {}, url = n => { n = n.split('/').pop(); const f = files.find(x => x.name === n); if (!f) throw new Error('нет файла ' + n); return urls[n] || (urls[n] = URL.createObjectURL(f.blob)); };
      for (const f of files) if (f.name !== 'mods.json' && /\.(json|js)$/i.test(f.name)) jobs.push({ name: f.name, text: await f.blob.text(), js: /\.js$/i.test(f.name), picked: true, res: url }); }
    let ul = []; try { ul = JSON.parse(localStorage.getItem('baldi.modurls') || '[]'); } catch (e) {}
    for (const u of ul) { try { jobs.push({ name: u.split('/').pop(), text: await (await fetch(u, { cache: 'no-cache' })).text(), res: p => new URL(p, u).href }); } catch (e) { modInfo.errors.push(u + ': ' + e.message); } }
    for (const j of jobs) { try { await applyMod(j, texQ); } catch (e) { modInfo.errors.push(j.name + ': ' + e.message); console.error('[baldi mod]', j.name, e); } }
    for (const [k, i] of texQ) img[k] = i;
    px.carpet = pix(img.carpet); px.brick = pix(img.brick); px.ceil = pix(img.ceil); px.door = pix(img.door);
    makeSprites(); if (menu) newGame();
  }
  async function pickMods() {
    try {
      if (modInfo.pendingHandle && (await modInfo.pendingHandle.requestPermission({ mode: 'read' })) === 'granted') { modInfo.pendingHandle = null; return loadMods(); }
      if (window.showDirectoryPicker) { const h = await window.showDirectoryPicker({ id: 'baldi-mods' }); await idbSet('mods', { kind: 'handle', handle: h }); return loadMods(); }
    } catch (e) { if (e.name === 'AbortError') return; modInfo.errors.push('выбор папки: ' + e.message); }
    const inp = document.createElement('input'); inp.type = 'file'; inp.multiple = true; inp.setAttribute('webkitdirectory', '');
    inp.onchange = async () => { const fs = [...inp.files].map(f => ({ name: f.name, blob: f })); if (!fs.length) return; await idbSet('mods', { kind: 'files', files: fs }); await loadMods(); };
    inp.click();
  }
  function modByUrl() {
    const u = prompt('Адрес мода (.json), например https://сайт/мод.json'); if (!u) return;
    if (!/^https?:\/\//i.test(u)) { modInfo.errors.push('ссылка должна начинаться с http(s)://'); return; }
    let ul = []; try { ul = JSON.parse(localStorage.getItem('baldi.modurls') || '[]'); } catch (e) {}
    if (!ul.includes(u)) ul.push(u); try { localStorage.setItem('baldi.modurls', JSON.stringify(ul)); } catch (e) {}
    loadMods().catch(e => modInfo.errors.push(e.message));
  }

  window.TMRLibs.baldi = {
    requires: ['audio'],
    init(rt) {
      r = rt;
      const off = (n, h) => { const e = r.libList.find(x => x.name === n); if (e) e.off.add(h); };
      off('physics', 'update'); off('renderer', 'render');
      for (const k in IMG) img[k] = r.assets.getImage(TX + k + '.' + IMG[k]); Object.assign(IMG0, img);
      const need = ['carpet', 'brick', 'ceil', 'door', 'wood', 'baldi', 'book', 'lk1', 'lk2', 'm3', 'broom', 'cart', 'nokia'].filter(k => !img[k]);
      if (need.length) throw new Error('Нет текстур: ' + need.join(', ') + ' (папка textures/)');
      px.carpet = pix(img.carpet); px.brick = pix(img.brick); px.ceil = pix(img.ceil); px.door = pix(img.door);
      makeSprites();
      for (const [k, f] of [['music', 'learn'], ['q1', 'q1'], ['q2', 'q2']]) music[k] = new Audio('sounds/' + f + '.mp3');

      const pos = e => { const b = r.canvas.getBoundingClientRect(); return { x: (e.clientX - b.left) * r.view.width / b.width, y: (e.clientY - b.top) * r.view.height / b.height }; };
      r.canvas.addEventListener('pointerdown', e => {
        const p = pos(e); uiHit = false;
        if (menu) { uiHit = true; return; }
        if (quizOn) { uiHit = true; qOpts.forEach((o, i) => { if (o.box && hit(p, o.box)) answer(i); }); return; }
        if (r.state !== 'playing') return;
        for (let i = 0; i < 3; i++) if (hit(p, slotRect(i))) { sel = i; uiHit = true; }
        BTN.forEach((n, i) => { if (hit(p, btnRect(i))) { uiHit = true; if (n == 'run') autoRun = !autoRun; else if (n == 'door') openDoor(); else use(); } });
      });
      r.canvas.addEventListener('click', e => {
        if (!menu) return; const p = pos(e);
        if (hit(p, MENU.play)) { menu = false; track('music'); } else if (hit(p, MENU.mods)) pickMods(); else if (hit(p, MENU.url)) modByUrl();
      });
      const rel = () => { uiHit = false; }; r.canvas.addEventListener('pointerup', rel); r.canvas.addEventListener('pointercancel', rel);
      r.on('keydown', k => {
        if (menu) { if (k === 'enter' || k === 'space') { menu = false; track('music'); } return; }
        if (quizOn) { if (k >= '1' && k <= '3') answer(+k - 1); return; }
        if (r.state !== 'playing') return;
        if (k >= '1' && k <= '3') sel = +k - 1; else if (k === 'e') use(); else if (k === 'o') openDoor(); else if (k === 'q') autoRun = !autoRun;
      });
      r.on('state', (s, prev) => { if (s === 'paused') for (const k in music) music[k].pause(); else if (s === 'playing' && cur && !menu) track(cur); else if (s === 'won' || s === 'lost') track(null); });
      r.on('reset', () => { newGame(); if (firstReset) { firstReset = false; menu = true; track(null); } else menu = false; if (!menu) track('music'); });
      loadMods().catch(e => modInfo.errors.push(e.message));
    },
    tick(rt) {
      for (const k in music) music[k].muted = muted();
      if (uiHit && rt.input) { rt.input.stick.active = false; rt.input.axis.x = 0; rt.input.axis.y = 0; }
    },
    update,
    render(rt) {
      const g = rt.ctx, V = rt.view;
      g.imageSmoothingEnabled = false;
      if (menu) {
        g.fillStyle = '#000'; g.fillRect(0, 0, V.width, V.height); const i = img.title;
        if (i) { const h = V.height, w = i.naturalWidth * h / i.naturalHeight; g.drawImage(i, V.width / 2 - w / 2, 0, w, h); }
        g.textBaseline = 'alphabetic';
        g.textAlign = 'center'; g.font = '15px system-ui';
        lab(g, 'START — играть · OPTIONS — моды (папка) · EXIT — мод по ссылке', V.width / 2, V.height - 42, '#aaa');
        if (modInfo.errors.length) lab(g, 'Ошибка мода: ' + modInfo.errors[modInfo.errors.length - 1].slice(0, 80), V.width / 2, V.height - 20, '#f99');
        else lab(g, 'Моды: ' + (modInfo.names.length ? modInfo.names.join(', ') : 'нет'), V.width / 2, V.height - 20, '#ccc');
        rt.setStatus("Baldi's Basics: главное меню"); return;
      }
      render(); g.drawImage(oc, 0, 0, V.width, V.height); g.imageSmoothingEnabled = true;
      drawUI(g);
      if (quizOn) drawQuiz(g);
      if (rt.state === 'paused') { rect(g, 0, 0, V.width, V.height, 'rgba(0,0,0,.7)'); g.textAlign = 'center'; g.font = 'bold 52px system-ui'; lab(g, 'ПАУЗА', V.width / 2, V.height / 2); g.font = '20px system-ui'; lab(g, 'P или клик — продолжить', V.width / 2, V.height / 2 + 40, '#fc4'); }
      if (rt.state === 'won' || rt.state === 'lost') drawEnd(g);
      rt.setStatus(rt.state === 'won' ? 'Победа!' : rt.state === 'lost' ? 'Поражение' : 'Тетради: ' + got + '/7');
    }
  };
})();

/* Игровая логика демо: рекорд времени в сохранении + подсказка. Пример «игровой» библиотеки. */
(() => {
  window.TMRLibs = window.TMRLibs || {};
  window.TMRLibs.crystalRun = {
    requires: ["save"],
    init(r) {
      const show = () => {
        const b = r.save && r.save.get("best", null);
        r.hud.set("Рекорд", b ? `${b.time.toFixed(1)} с · ${b.score} оч.` : "—");
      };
      r.on("reset", show);
      r.on("win", () => {
        const b = r.save && r.save.get("best", null), cur = { time: r.elapsed, score: r.score };
        if (r.save && (!b || cur.time < b.time)) {
          r.save.set("best", cur);
          r.emit("float", { x: r.player.x, y: r.player.y - 30, text: "Новый рекорд!", color: "#34d399" });
        }
        show();
      });
    }
  };
})();

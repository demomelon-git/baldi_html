TMR Engine 0.3.0 (2D + 3D)

ЗАПУСК
1. Распакуйте архив, откройте терминал в папке.
2. python start.py   (откроет http://localhost:8000/TMR.html; сервер слушает только ваш компьютер)
file:// не работает: браузеры блокируют fetch JSON. Движок сам покажет подсказку.

КЛАВИШИ
WASD / стрелки — движение (работает и на русской раскладке), P или Esc — пауза, R — заново,
F — полный экран, M — звук, F3 — отладка (fps, хитбоксы), Enter/клик — заново после конца игры.
Телефон: тяните пальцем по полю (виртуальный стик). Геймпад: стик/крестовина, Start — пауза.

ФАЙЛЫ
TMR.html            оболочка и кнопки
engine.js           ядро: цикл, события, ресурсы, ввод, загрузка библиотек
engine.json         конфиг и список библиотек
libraries/*-lib.js  input, save, physics, audio, renderer (любую можно убрать из списка или заменить своей)
games/game.json     демо-игра; games/crystal-run.js — пример игровой библиотеки
start.py            локальный сервер
libraries/physics3d-lib.js, renderer3d-lib.js — режим 3D; games/game3d.json — демо 3D

ЧТО НОВОГО В 0.3.0: РЕЖИМ 3D
Включается одной строкой в game.json: "mode": "3d" (без неё — обычный 2D, всё как раньше).
Демо: http://localhost:8000/TMR.html?game=games/game3d.json (ссылки есть внизу страницы).
- Свой WebGL-рендер без внешних библиотек (работает без интернета): коробки, сферы, цилиндры, свет, туман, сетка на поверхностях, частицы
- Камера от 1-го и 3-го лица (V), прицел, тряска при уроне
- Физика: гравитация, прыжок (с «койот-таймом»), бег (Shift), коллизии со стенами и платформами, движущиеся платформы переносят игрока,
  падение за край (world.ground:false, world.killY) = потеря жизни
- Управление: клавиатура + мышь (клик по полю захватывает курсор, Esc — пауза), стрелки — обзор;
  телефон: слева ходьба, справа обзор, круг справа внизу — прыжок; геймпад: левый стик, правый стик — обзор, A — прыжок
- Одни и те же типы сущностей, события, звук, сохранения и HUD, что и в 2D
- Библиотеки можно помечать режимом: {"path": "...", "mode": "2d"|"3d"} — грузятся только для нужного режима
- TMR.html теперь с кадром #frame и слоем HUD #tmr-hud (для 3D нужен именно этот TMR.html); полноэкранный режим растягивает всю сцену

ФОРМАТ 3D (game.json)
Оси: x, z — пол, y — вверх. Координаты сущностей — ЦЕНТР (стена высотой 4 на земле: y = 2). Для игрока y — уровень ног.
world: width, depth (размер пола с центром в 0,0), background (небо и туман), ground (цвет пола или false = пустота), gravity (24),
       fog (true/false), fogDensity, killY, bounded
player: x,y,z, yaw (поворот, 0 = смотрит в -z), radius (0.35), height (1.7), speed (6), jump (8), lives, camera ("first"|"third"),
        cameraDistance, fov, sensitivity, color
Сущности:
  wall / box   width,height,depth, color   wall — твёрдая; box — декор (solid:true делает твёрдой)
  sphere       radius, color
  collectible  radius, value, color        кристалл
  hazard       radius | width,height,depth, move:{axis:"x"|"y"|"z",range,speed,phase}
  goal         radius,height | width,height,depth, requires:"collectibles"
Любой wall/hazard может иметь move. Поле "hint" в game.json — подсказка на первые 8 секунд.
Пока в 3D нет текстур и моделей из файлов (только цветные примитивы).

ЧТО НОВОГО В 0.2.0
- Фиксированный шаг физики (60 Гц) и интерполяция: одинаковое поведение на любом мониторе
- События: runtime.on("collect"|"hit"|"win"|"lose"|"reset"|"state"|"keydown"|"spawn"|...)
- Состояния: playing / paused / won / lost, пауза при потере фокуса, перезапуск
- Физика: скольжение по стенам вместо «залипания», подшаги против пролёта сквозь стены,
  опасности (hazard) с жизнями, движущиеся объекты, цель (goal), режим платформера (world.gravity > 0)
- Исправлено: уровень без кристаллов больше не «выигрывается» сразу
- Камера, мир больше экрана, тряска, частицы, всплывающие тексты, HUD, спрайт-листы, слои z
- Звук: эффекты из MP3 или встроенный синтезатор (работает без файлов), громкость, M — mute
- Сохранения: localStorage + необязательная папка на диске (кнопка «Папка сохранений», Chrome/Edge)
- Ввод по физическим клавишам (KeyW), мышь, касания, геймпад
- Устойчивость: ошибка в библиотеке не роняет игру (hook отключается после 10 ошибок);
  необязательные библиотеки: {"path": "...", "required": false}; проверка зависимостей (lib.requires)
- Безопасность: пути библиотек и ?game= только относительные внутри проекта; чужой код по ссылке не подгрузится
- Чёткий холст на Retina ("pixelRatio": "auto"), pixelArt-режим, ?game=games/other.json

ФОРМАТ game.json (совместим с 0.1)
id, title, world{width,height,background,gravity,grid,gridSize}, player{x,y,radius,speed,color,texture,lives,jump,invulnTime},
audio{music,volume,sfxVolume,sfx{collect|hit|win|lose|jump: "файл.mp3" или {freq,to,dur,type} или {notes:[...]}},defaults},
messages{pause,win,lose,winSub,loseSub}, libraries[], preload[], entities[]
Сущности (общие поля: x,y,z,texture,color):
  wall         width,height                  твёрдая стена (или любой объект с solid:true)
  collectible  radius,value                  кристалл
  hazard       radius | width,height, move   урон; move:{axis:"x"|"y",range,speed,phase}
  goal         radius | width,height, requires:"collectibles"   победа при касании
  sprite       width,height,texture,frames,fps   спрайт-лист по горизонтали
  text         text,size,align
PNG кладите в textures/, MP3 в sounds/ и указывайте пути в game.json — без файлов игра работает на фигурах и синтезе.

API ДЛЯ БИБЛИОТЕК
Файл делает window.TMRLibs.<имя> = { requires?, init(r), tick(r,dt), update(r,dt), render(r,alpha), endFrame(r) }
 tick — каждый кадр; update — шаг физики 1/60 с, только в состоянии playing; render — отрисовка.
r (runtime): state, setState(), pause()/resume()/restart(), player, entities, add(e)/remove(e)/find(t)/count(t),
 world, view{width,height,dpr}, camera{x,y,zoom,shake}, score, lives, hud (Map), keys, pressed (нажато в этом кадре),
 axis() (вектор движения), screenToWorld(), assets.getImage(path), on/once/off/emit, elapsed, clock, dt, fps, debug,
 save.get/set (save-lib), input.pointer/stick (input-lib).
Рисуйте в логических координатах r.view.width × r.view.height, а не canvas.width (при pixelRatio > 1 они различаются).
Подключение: добавьте путь в "libraries" в engine.json (на все игры) или в game.json (только для игры).

ВАЖНО
Библиотеки выполняются как обычный JavaScript — подключайте только доверенные файлы.


ИГРА BALDI'S BASICS (games/baldi.json, games/baldi-lib.js)
Запуск: python start.py (по умолчанию открывается она; демо: TMR.html?game=games/game.json).
Тетради в 7 зелёных классах, викторина, добрый Балди -> злой после 2-й тетради, директор Заусенец (наказывает за бег),
метла, тележка, инвентарь (1-3, E - Nokia), бег (Shift / Q / кнопка), столовая, 2 концовки.
Текстуры лежат в textures/, звуки в sounds/ - можно заменить файлы с теми же именами. Рекорд времени хранится через save-lib.

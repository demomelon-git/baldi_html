// Пример JS-мода. Подключается так же, как JSON-мод. Доступен объект api.
api.on('collect', n => { if (n == 3) api.say('Три тетради! Ты молодец!', 2500); });
api.on('start', () => api.giveItem('bar'));

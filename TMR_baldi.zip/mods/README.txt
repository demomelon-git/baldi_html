МОДЫ ДЛЯ BALDI'S BASICS

Как подключить (любой способ):
1) Положите файл мода в папку mods/ и впишите его имя в mods/mods.json: {"mods": ["example-mod.json"]}
   (игра сама запрашивает mods/mods.json при запуске; в APK папка mods/ попадает в приложение)
2) В главном меню нажмите на надпись OPTIONS и выберите папку mods (в Chrome/Edge на компьютере) или выберите файлы мода
   и картинки/звуки к нему (на телефоне). Выбор запоминается.
3) надпись EXIT (мод по ссылке) - адрес на .json мод в интернете.

ФОРМАТ JSON-МОДА
{ "name": "Мой мод",
  "settings": { "walkSpeed": 3.2, "runSpeed": 5.8, "staminaDrain": 22, "staminaRegen": 14,
                "baldiCalm": 0.9, "baldiBase": 1.5, "baldiPer": 0.3, "baldiSize": 1,
                "detention": 15, "nokiaStun": 10, "principalSpeed": 1.6, "broomSpeed": 2.8, "cartSpeed": 1.2,
                "doorReach": 1.7, "startItems": ["nokia","bar"], "extraItems": {"bar": 2} },
  "items": [ { "id": "cola", "icon": "🥤", "name": "Газировка", "effect": "stun", "value": 6, "spawn": 3 } ],
  "textures": { "baldi": "baldi.png", "carpet": "my-floor.png" },
  "sounds": { "music": "song.mp3", "door": "door.mp3", "win": "win.mp3", "lose": "lose.mp3" } }
effect предмета: place (положить, как Nokia), stamina (+value выносливости), stun (Балди замирает value с), teleport (телепорт Балди), speed (ускорение value с).
Имена текстур: carpet brick ceil door wood baldi book lk1 lk2 m1 m2 m3 cart broom nokia dab good rare title slots.
JS-мод (.js) получает объект api: settings, items, defItem(), on('start'|'update'|'use'|'collect', fn), say(), state(), giveItem(id). Подключайте только доверенный код.
